/////////////////////////////////////////////////////////////////////////////
// Name:        src/motif/data.cpp
// Purpose:     Various Motif-specific global data
// Author:      Julian Smart
// Modified by:
// Created:     17/09/98
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// this file is empty for now but a translation unit is not supposed to be
// completely empty
extern int wxMotifDummyData;

